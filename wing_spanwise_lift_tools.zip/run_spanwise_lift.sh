#!/usr/bin/env bash
# OpenFOAM Foundation v13: extract and plot sectional lift on both wings.
# Unpack all three provided files in ~/OpenFOAM/wingFresh, then run:
#     bash run_spanwise_lift.sh
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v foamPostProcess >/dev/null 2>&1; then
    echo "ERROR: foamPostProcess is not available. Source OpenFOAM 13 first." >&2
    exit 1
fi

for case_dir in "$project_dir" "$project_dir/sweep_15"; do
    if [[ ! -f "$case_dir/system/controlDict" ]]; then
        echo "ERROR: OpenFOAM case missing at $case_dir" >&2
        exit 1
    fi

    config_target="$case_dir/system/spanwiseLiftDict"
    if [[ -e "$config_target" ]]; then
        if ! cmp -s "$project_dir/spanwiseLiftDict" "$config_target"; then
            echo "ERROR: $config_target already exists with different content." >&2
            echo "Please review it; this script will not overwrite it." >&2
            exit 1
        fi
    else
        cp "$project_dir/spanwiseLiftDict" "$config_target"
    fi

    echo "Post-processing spanwise force bins: $case_dir (t=1.1 s)"
    (
        cd "$case_dir"
        foamPostProcess -solver incompressibleFluid \
            -dict system/spanwiseLiftDict -time 1.1
    )
done

echo "Plotting unswept vs 15-degree swept loading..."
python3 "$project_dir/plot_spanwise_lift.py" \
    --unswept "$project_dir" \
    --swept "$project_dir/sweep_15" \
    --time 1.1 \
    --output "$project_dir/postProcessing/analysis_figures"

echo "Finished: $project_dir/postProcessing/analysis_figures/spanwise_lift_comparison.png"
