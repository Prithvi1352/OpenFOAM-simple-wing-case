#!/usr/bin/env python3
"""Compare sectional lift loading from OpenFOAM 13 forceCoeffs_bins.dat.

Run from ~/OpenFOAM/wingFresh after generating the bin data in both cases:
    python3 plot_spanwise_lift.py

Only the Python standard library and Matplotlib are required (no pandas).
All quantities are checked against the total force coefficient when available.
"""

import argparse
import csv
import math
import re
from dataclasses import dataclass
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


FLOAT = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?"


@dataclass
class Bins:
    case_name: str
    time: float
    n: int
    start: float
    delta: float
    y: list
    eta: list
    cl_bin: list
    cl_section: list
    lift_per_span: list
    cl_total: float
    path: Path


def metadata_float(line, key):
    m = re.match(rf"^#\s*{re.escape(key)}\s*:?\s*({FLOAT})\b", line)
    return float(m.group(1)) if m else None


def parse_binned_file(path, requested_time, case_name, area, chord, span, q_inf):
    count = None
    start = None
    delta = None
    direction = None
    rows = []

    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            count_match = re.match(r"^#\s*bins\s*:?\s*(\d+)\b", line)
            if count_match:
                count = int(count_match.group(1))
            for key in ("start", "delta"):
                val = metadata_float(line, key)
                if val is not None:
                    if key == "start":
                        start = val
                    else:
                        delta = val
            dm = re.match(r"^#\s*direction\s*:?\s*\(([^)]+)\)", line)
            if dm:
                direction = tuple(float(x) for x in dm.group(1).split())
            continue
        try:
            row = [float(x) for x in line.split()]
        except ValueError:
            continue
        if row:
            rows.append(row)

    if count is None or start is None or delta is None:
        raise ValueError(f"Missing bins/start/delta metadata in {path}")
    if direction is None or len(direction) != 3 or not all(
        math.isclose(a, b, abs_tol=1e-6)
        for a, b in zip(direction, (0.0, 1.0, 0.0))
    ):
        raise ValueError(f"Expected spanwise direction (0 1 0) in {path}; got {direction}")
    if count <= 0 or delta <= 0:
        raise ValueError(f"Invalid bin count or spacing in {path}")

    matching = [r for r in rows if math.isclose(r[0], requested_time, abs_tol=1e-6)]
    if not matching:
        raise ValueError(f"No t={requested_time:g} row in {path}")
    row = matching[-1]
    if len(row) != 1 + 3 * count:
        raise ValueError(
            f"Expected {1 + 3 * count} numeric columns in {path}, got {len(row)}"
        )
    if not all(math.isfinite(v) for v in row):
        raise ValueError(f"Non-finite force coefficients in {path}")

    # OpenFOAM v13 writes: Time Cm(0) Cd(0) Cl(0) Cm(1) Cd(1) Cl(1) ...
    cl_bin = [row[1 + 3 * i + 2] for i in range(count)]
    y = [start + (i + 0.5) * delta for i in range(count)]
    eta = [2.0 * yy / span for yy in y]
    # Cl_bin = L_bin / (qInf * Aref); sectional cl = L_bin / (qInf * c * dy).
    cl_section = [v * area / (chord * delta) for v in cl_bin]
    lift_per_span = [v * q_inf * area / delta for v in cl_bin]
    cl_total = sum(cl_bin)

    if abs(count * delta - span) > 0.05 * span:
        raise ValueError(
            f"Binned width {count * delta:g} m differs significantly "
            f"from configured span {span:g} m in {path}"
        )

    # OpenFOAM writes the integrated coefficient alongside the bin file.
    overall = path.with_name("forceCoeffs.dat")
    if overall.is_file():
        for raw in overall.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            try:
                vals = [float(x) for x in line.split()]
            except ValueError:
                continue
            if len(vals) >= 4 and math.isclose(vals[0], requested_time, abs_tol=1e-6):
                if not math.isclose(cl_total, vals[3], rel_tol=2e-3, abs_tol=1e-5):
                    raise ValueError(
                        f"Cl checksum failed for {case_name}: bins sum to {cl_total:.6g}, "
                        f"but overall forceCoeffs.dat reports {vals[3]:.6g}. "
                        "Do not use this plot until resolved."
                    )
                break

    return Bins(case_name, row[0], count, start, delta, y, eta,
                cl_bin, cl_section, lift_per_span, cl_total, path)


def find_bins(case, requested_time, case_name, area, chord, span, q_inf):
    base = case / "postProcessing" / "spanwiseLift"
    candidates = sorted(base.glob("*/forceCoeffs_bins.dat"))
    if not candidates:
        raise FileNotFoundError(
            f"No forceCoeffs_bins.dat under {base}. "
            "First run foamPostProcess with system/spanwiseLiftDict."
        )
    errors = []
    for path in candidates:
        try:
            return parse_binned_file(path, requested_time, case_name,
                                     area, chord, span, q_inf)
        except ValueError as exc:
            errors.append(str(exc))
    raise ValueError("Could not read requested time from bin files:\n" + "\n".join(errors))


def create_plot(unswept, swept, output):
    plt.rcParams.update({"font.size": 11, "axes.spines.top": False,
                         "axes.spines.right": False, "savefig.dpi": 190})
    fig, (ax, diff_ax) = plt.subplots(
        2, 1, figsize=(11, 7.5), sharex=True,
        gridspec_kw={"height_ratios": [3, 1.4]}, constrained_layout=True
    )
    ax.plot(unswept.eta, unswept.cl_section, color="#1265A8", linewidth=2.4,
            marker="o", markersize=3.0,
            label=f"Unswept  ($C_L$={unswept.cl_total:.4f})")
    ax.plot(swept.eta, swept.cl_section, color="#E46C20", linewidth=2.4,
            marker="s", markersize=3.0,
            label=f"15° swept  ($C_L$={swept.cl_total:.4f})")
    ax.set_ylabel("Sectional lift coefficient, $c_l(y)$")
    ax.set_title(f"Spanwise lift loading at $t={unswept.time:g}$ s", fontsize=16, pad=12)
    ax.axvline(0.0, color="black", alpha=0.15)
    ax.grid(alpha=0.23)
    ax.legend(frameon=False, loc="best")

    if unswept.n != swept.n or any(abs(a - b) > 0.02
                                     for a, b in zip(unswept.eta, swept.eta)):
        raise ValueError("Wing bin locations do not align closely enough to subtract.")
    differences = [a - b for a, b in zip(swept.cl_section, unswept.cl_section)]
    diff_ax.plot(swept.eta, differences, color="#476A51", linewidth=2)
    diff_ax.fill_between(swept.eta, 0.0, differences, color="#476A51", alpha=0.18)
    diff_ax.axhline(0.0, color="black", linewidth=0.9)
    diff_ax.axvline(0.0, color="black", alpha=0.15)
    diff_ax.grid(alpha=0.23)
    diff_ax.set_ylabel(r"$\Delta c_l$ (swept − unswept)")
    diff_ax.set_xlabel("Normalized spanwise position, $2y/b$")
    diff_ax.set_xlim(-1.05, 1.05)

    fig.text(0.5, -0.015,
             "40 non-cumulative OpenFOAM force bins; pressure + viscous loading. "
             "Both cases use the same freestream and reference area.",
             ha="center", va="top", fontsize=9, color="#555555")
    fig.savefig(output, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--unswept", type=Path, default=Path("."))
    p.add_argument("--swept", type=Path, default=Path("sweep_15"))
    p.add_argument("--time", type=float, default=1.1)
    p.add_argument("--aref", type=float, default=5.0, help="Wing reference area (m^2)")
    p.add_argument("--span", type=float, default=5.0, help="Wing reference span (m)")
    p.add_argument("--chord", type=float, default=1.0, help="Constant chord (m)")
    p.add_argument("--rho", type=float, default=1.225, help="Density (kg/m^3)")
    p.add_argument("--speed", type=float, default=20.0, help="Freestream speed (m/s)")
    p.add_argument("--output", type=Path, default=Path("postProcessing/analysis_figures"))
    args = p.parse_args()
    for name in ("aref", "span", "chord", "rho", "speed"):
        if getattr(args, name) <= 0:
            p.error(name + " must be positive")

    q_inf = 0.5 * args.rho * args.speed ** 2
    unswept = find_bins(args.unswept, args.time, "unswept", args.aref,
                        args.chord, args.span, q_inf)
    swept = find_bins(args.swept, args.time, "swept_15deg", args.aref,
                      args.chord, args.span, q_inf)

    args.output.mkdir(parents=True, exist_ok=True)
    img = args.output / "spanwise_lift_comparison.png"
    table = args.output / "spanwise_lift_comparison.csv"
    create_plot(unswept, swept, img)

    with table.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["case", "time_s", "y_m", "eta_2y_over_b", "Cl_bin",
                         "sectional_cl", "lift_per_span_N_per_m"])
        for data in (unswept, swept):
            for j in range(data.n):
                writer.writerow([data.case_name, data.time, data.y[j], data.eta[j],
                                 data.cl_bin[j], data.cl_section[j],
                                 data.lift_per_span[j]])

    print(f"Unswept: {unswept.path} | bins={unswept.n} | sum(Cl_bin)={unswept.cl_total:.6f}")
    print(f"Swept:   {swept.path} | bins={swept.n} | sum(Cl_bin)={swept.cl_total:.6f}")
    print("Saved:", img)
    print("Saved:", table)


if __name__ == "__main__":
    main()
